import React from 'react';

import Map from './Map'



export default function App (){
 
     return (
       <Map>
       </Map>
     ) 
        
   
}

